READ_ME

THIS IS THE FOLDER FOR INSTALLING AND CHECK EXISTING PORT. IT CONTAINS:

bin: Contain all binaries file of exporter

install.sh: Script for handling about check exsiting port, create, start and check status of service

yaml_handler: contain YAML file and script for get value from it.
